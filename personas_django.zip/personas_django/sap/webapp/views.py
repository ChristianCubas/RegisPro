from django.http import HttpResponse
from django.shortcuts import render

from personas.models import Persona


# Create your views here.
def bienvenido(request):
    n_personas = Persona.objects.count()
    persona = Persona.objects.all()
    return render(request,"bienvenido.html",{"nro_personas":n_personas,"persona":persona})

def contacto(request):
    return HttpResponse("correo: christiancubasjaramillo@gmail.com")